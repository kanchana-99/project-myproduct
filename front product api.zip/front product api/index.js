function loadPro(){
    const xhttp = new XMLHttpRequest();
    xhttp.open("GET","http://localhost:5000/product-namfon");
    xhttp.send();
    xhttp.onreadystatechange = function(){
        if(this.readyState == 4 && this.status == 200){
            const objects = JSON.parse(this.responseText);
            var trHTML = '';
            for(let object of objects){
                trHTML += '<tr>';
                trHTML += '<td>' + object['id'] + '</td>';
                trHTML += '<td><img width="50px" src="' + object['product_img'] + '"> </td>';
                trHTML += '<td>' + object['product_name'] + '</td>';
                trHTML += '<td>' + object['product_cost'] + '</td>';
                trHTML += '<td>' + object['product_price'] + '</td>';
                trHTML += '<td><button type="button" class="btn btn-outline-secondary" onclick="showUserEditBox('+ object['id'] +')"> แก้ไข </td>';
                trHTML += '<td><button type="button" class="btn btn-outline-danger" onclick="showUserDelete('+ object['id'] +')"> ลบ </td>';
                trHTML += '</tr>';
            }
            document.getElementById("mytable").innerHTML = trHTML;
        }
    }
}
 
loadPro()

function showUserEditBox(id) {
    console.log(id);
    const xhttp = new XMLHttpRequest();
    xhttp.open("GET", "http://localhost:5000/product-namfon/" + id);
    xhttp.send();
    xhttp.onreadystatechange = function () {
      if (this.readyState == 4 && this.status == 200) {
        const objects = JSON.parse(this.responseText);
        const object = objects[0]; // Assume only one object is returned.
   
        Swal.fire({
          title: "Edit User",
          html : 'ID : <input id="id" type="hidden" value='+ object.id +'>' + 
                 '<br>product_name : <input id="product_name" type="text" class="Swal2-input" value='+ object.product_name +'>'+ 
                 '<br>product_cost : <input id="product_cost" type="text" class="Swal2-input" value='+ object.product_cost +'>'+ 
                 '<br>product_price : <input id="product_price" type="text" class="Swal2-input" value='+ object.product_price +'>'+ 
                 '<br>product_img : <input id="product_img" type="text" class="Swal2-input" value='+ object.product_img +'>', 
          focusConfirm : false,
          preConfirm: () =>{userEdit();}
        });
      }
    };
}

function showProDelete(id) {
    Swal.fire({
        title: "แน่ใจที่จะลบข้อมูลนี้?",
        text: "You will not be able to recover this user!",
        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#d33",
        cancelButtonColor: "#3085d6",
        confirmButtonText: "ใช่แน้ว!"
    }).then((result) => {
        if (result.isConfirmed) {
            const xhttp = new XMLHttpRequest();
            xhttp.open("DELETE", "http://localhost:5000/product-namfon/delete");
            xhttp.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
 
            xhttp.send(JSON.stringify({ "id": id }));
 
            xhttp.onreadystatechange = function () {
                if (this.readyState == 4 && this.status == 200) {
                    Swal.fire("ลบข้อมูลแน้ว!", "ข้อมูลถูกลบสำเร็จ.", "สำเร็จ");
                    loadUser(); // โหลดข้อมูลใหม่หลังจากลบ
                }
            }
        }
    });
}
 
 
